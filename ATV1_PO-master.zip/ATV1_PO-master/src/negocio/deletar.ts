export default abstract class Deletar {
    public abstract deletar(): void
}