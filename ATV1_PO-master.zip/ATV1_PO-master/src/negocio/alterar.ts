export default abstract class Alterar {
    public abstract alterar(): void
}